<template>
  <v-app>
    <v-main>
      <router-view />
    </v-main>

  </v-app>
</template>

<script setup>
import { routePath } from '@/utils/constant';
import { onMounted } from 'vue';
import { useRouter } from 'vue-router';

const { push } = useRouter();

onMounted(() => {
  push(routePath.login)
})
//
</script>
