
<script >
import PortalHeader from '@/components/PortalHeader.vue';
import TenantFrom from '@/components/TenantFrom.vue';

  export default {
    components: {
      PortalHeader,
      TenantFrom
    }
  }
</script>


<template>
  <PortalHeader title='Add Tenant'/>
  <TenantFrom  />
 
    
</template>





<style>

</style>