<script setup>
// defineProps({
//   msg: {
//     type: String,
//     required: true
//   }
// })
import { ref } from "vue";

// Static Values for Now
const states = ref(['California', 'Colorado', 'Florida', 'Georgia', 'Texas', 'Wyoming']);
const countries = ref(['United States', 'United Kindom', 'China', 'Japan']);
const proprty_type_list = ref(['Mixed Portfolia', 'Commercial', 'Residentail'])
const hoa_list = ref(['HOA 89'])
const owners = ref(['John Doe', 'Jane Smith', 'Tom Brown', 'Harry White'])
const lease_terms = ref(['6 month', '9 month', '12 month', '2 year', '5 year'])
const property_status_list = ref(["For Rent", "For Sale", "For Rent or Sale"])

//Field properties
const PropertyName = ref();
const PropertyType = ref();
const HOA = ref();
const PropertyStatus = ref();
const MarketRent = ref();
const ApplicationFee = ref();
const Deposit = ref();
const SalePrice = ref();
const LeaseTerms = ref();
const Notes = ref();
const Owners = ref();
const Comments = ref();
const Location = ref();
const City = ref();
const Address1 = ref();
const Address2 = ref()
const country = ref("America");
const state = ref();
const ZipCode = ref();
const CountryName = ref();


//API Calling Using fetch

// async function get_json(url, type) {
//   try {
//     const response = await fetch(url, {
//       method: "GET",
//       headers: { "Content-Type": "application/json" },
//     });

//     if (!response.ok) {
//       throw new Error("Failed to fetch data");
//     }

//     const responseData = await response.json(); // Wait for the JSON parsing to complete
//     // Assign the fetched data to states.value
//     if (type == "states") {
//       states.value = responseData.data;
//     } else {
//       countries.value = responseData.data;
//     }
//     // return responseData.data
//   } catch (error) {
//     console.error("Error fetching data:", error.message);
//     // Handle errors gracefully
//   }
// }

// async function change_country(event) {
//   try {
//     country.value = event;
//     const id = countries.value
//       .filter((n) => n.name === event)
//       .map((o) => o.id)[0];
//     const state_value = await getRequest("http://localhost:5114/api/v1/state/country/" +id,null)
//     states.value=state_value.data.data

//   } catch (e) {
//     console.error("Change_Country function Error: ", e.message);
//   }
// }

// async function get_everything() {
//   // await get_json(
//   //   "http://localhost:5114/api/v1/country/all?initialValue=" + country,
//   //   "countries"
//   // );
//   //  await get_json(
//   //   "http://localhost:5114/api/v1/state/country/" + countries.value[0].id,
//   //   "states"
//   // );
//   const country_value=await getRequest("http://localhost:5114/api/v1/country/all?initialValue=" + country,null)
//   countries.value=country_value.data.data
//   const value=await getRequest("http://localhost:5114/api/v1/state/country/" + countries.value[0].id,null)
//   states.value=value.data.data
// }

// onMounted(async () => {
//   await get_everything();
// });


</script>

<template>
    <div id="prakash">
        <div id="first">
            <div id="add">
                <h1>Add Property</h1>
            </div>
            <div id="inner"></div>
            <div id="buttons">
                <v-btn variant="outlined" rounded="lg" size="x-large" class="btn">
                    Cancel
                </v-btn>
                <v-btn variant="outlined" rounded="lg" size="x-large" class="btn-new">
                    Save
                </v-btn>
                <v-btn variant="outlined" rounded="lg" size="x-large" class="btn-new">
                    Save and New
                </v-btn>
            </div>
        </div>
        <div id="middle-1">
            <div id="text">
                <svg width="22" height="17" viewBox="0 0 22 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M16.1154 5.38461H17.8846V3.61541H16.1154V5.38461ZM16.1154 9.38461H17.8846V7.61541H16.1154V9.38461ZM16.1154 13.3846H17.8846V11.6154H16.1154V13.3846ZM0.5 17V7.75003L6.99998 3.11543L13.5 7.75003V17H8.92305V11.4615H5.0769V17H0.5ZM15.5 17V6.75003L9.1923 2.20968V3.05176e-05H21.5V17H15.5Z"
                        fill="#789F48"></path>
                </svg>
                <h3>Property</h3>
            </div>

            <div id="middle-first">
                <div id="first-row">
                    <v-text-field variant="outlined" label="Property Name" border="black" required
                        v-model="PropertyName" :style="{ 'width': '75px' }"
                        :rules="[() => !!PropertyName || 'Property Name is Required']"></v-text-field>
                    <v-select label="Property Type" v-model="PropertyType" variant="outlined"
                        :style="{ 'width': '75px' }" :rules="[() => !!PropertyType || 'Property Type is Required']"
                        :items="proprty_type_list" border="black"></v-select>
                    <v-select label="HOA" variant="outlined" :style="{ 'width': '75px' }" v-model="HOA"
                        :items="hoa_list" border="black"></v-select>
                    <v-select variant="outlined" v-model="PropertyStatus" label="Property Status"
                        :style="{ 'width': '75px' }" :items="property_status_list" border="black"></v-select>
                </div>
            </div>
            <div id="middle-second">
                <div id="middle-second-1">
                    <v-text-field variant="outlined" label="Market Rent" v-model="MarketRent" border="black"
                        required></v-text-field>
                    <v-tooltip text="Default Market Rent for this Property">
                        <template v-slot:activator="{ props }">
                            <svg v-bind="props" class="icon" focusable="false" aria-hidden="true" viewBox="0 0 24 24"
                                data-testid="InfoOutlinedIcon" aria-label="Default Deposit for this Property">
                                <path
                                    d="M11 7h2v2h-2zm0 4h2v6h-2zm1-9C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8">
                                </path>
                            </svg>
                        </template>
                    </v-tooltip>
                </div>
                <div id="middle-second-1">
                    <v-text-field variant="outlined" label="Application Fee" v-model="ApplicationFee"
                        border="black"></v-text-field>
                    <v-tooltip text="Default Application Fee for this Property. Leave blank to use company default">
                        <template v-slot:activator="{ props }">
                            <svg v-bind="props" class="icon" focusable="false" aria-hidden="true" viewBox="0 0 24 24"
                                data-testid="InfoOutlinedIcon" aria-label="Default Deposit for this Property">
                                <path
                                    d="M11 7h2v2h-2zm0 4h2v6h-2zm1-9C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8">
                                </path>
                            </svg>
                        </template>
                    </v-tooltip>
                </div>
                <div id="middle-second-1">
                    <v-text-field variant="outlined" label="Deposit" v-model="Deposit" border="black"></v-text-field>
                    <v-tooltip text="Default Deposit for this Property">
                        <template v-slot:activator="{ props }">
                            <svg v-bind="props" class="icon" focusable="false" aria-hidden="true" viewBox="0 0 24 24"
                                data-testid="InfoOutlinedIcon" aria-label="Default Deposit for this Property">
                                <path
                                    d="M11 7h2v2h-2zm0 4h2v6h-2zm1-9C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8">
                                </path>
                            </svg>
                        </template>
                    </v-tooltip>
                </div>
                <div id="middle-second-1">
                    <v-text-field :style="{ width: '55px' }" variant="outlined" label="Available On" border="black"
                        type="date"></v-text-field>
                    <v-tooltip text="Used if Property is not available until a certain date">
                        <template v-slot:activator="{ props }">
                            <svg v-bind="props" class="icon" focusable="false" aria-hidden="true" viewBox="0 0 24 24"
                                data-testid="InfoOutlinedIcon" aria-label="Default Deposit for this Property">
                                <path
                                    d="M11 7h2v2h-2zm0 4h2v6h-2zm1-9C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8">
                                </path>
                            </svg>
                        </template>
                    </v-tooltip>
                </div>
            </div>
            <div id="middle-last">
                <div id="last-row">
                    <div id="last-row-inner">
                        <v-text-field variant="outlined" label="Sale Price" v-model="SalePrice"
                            border="black"></v-text-field>
                        <v-tooltip text="Default Sale Price for this Property">
                            <template v-slot:activator="{ props }">
                                <svg v-bind="props" class="icon" focusable="false" aria-hidden="true"
                                    viewBox="0 0 24 24" data-testid="InfoOutlinedIcon"
                                    aria-label="Default Deposit for this Property">
                                    <path
                                        d="M11 7h2v2h-2zm0 4h2v6h-2zm1-9C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8">
                                    </path>
                                </svg>
                            </template>
                        </v-tooltip>
                    </div>
                    <v-select label="Lease Terms" v-model="LeaseTerms" variant="outlined" :items="lease_terms"
                        border="black"></v-select>
                </div>
                <div id="last-row-1">
                    <v-text-field :style="{ 'padding-right': '20px' }" variant="outlined" label="Notes" v-model="Notes"
                        border="black"></v-text-field>
                </div>
            </div>
            <div id="text-new">
                <v-checkbox label="Do Not Advertise"></v-checkbox>
            </div>
        </div>
        <div id="middle-2">
            <div id="first-row-middle2">
                <svg width="20" height="17" viewBox="0 0 20 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M8.25 17V15.3863C8.25 15.089 8.32788 14.8119 8.48365 14.5548C8.63942 14.2978 8.84486 14.0904 9.09998 13.9327C9.84741 13.4891 10.6324 13.1555 11.4548 12.9317C12.2772 12.708 13.1256 12.5962 14 12.5962C14.8743 12.5962 15.7227 12.708 16.5452 12.9317C17.3676 13.1555 18.1525 13.4891 18.9 13.9327C19.1551 14.0904 19.3605 14.2978 19.5163 14.5548C19.6721 14.8119 19.75 15.089 19.75 15.3863V17H8.25ZM0.5 17V5.75004L7.99998 0.105835L12.6826 3.63656C11.6249 3.89554 10.7564 4.459 10.0769 5.32694C9.39741 6.19489 9.05768 7.18526 9.05768 8.29806C9.05768 8.82756 9.13332 9.32949 9.2846 9.80384C9.43588 10.2782 9.65448 10.7154 9.94038 11.1154C9.59421 11.2487 9.25942 11.3891 8.936 11.5366C8.61257 11.6842 8.29351 11.8534 7.97883 12.0442C7.38524 12.3942 6.91665 12.8704 6.57305 13.4728C6.22947 14.0752 6.05768 14.7138 6.05768 15.3885V17H0.5ZM14.0011 11.0481C13.2375 11.0481 12.5881 10.7808 12.0529 10.2463C11.5176 9.71181 11.25 9.06278 11.25 8.29921C11.25 7.53564 11.5173 6.88623 12.0518 6.35096C12.5863 5.81571 13.2353 5.54809 13.9989 5.54809C14.7624 5.54809 15.4118 5.81534 15.9471 6.34984C16.4823 6.88434 16.75 7.53337 16.75 8.29694C16.75 9.0605 16.4827 9.70992 15.9482 10.2452C15.4137 10.7804 14.7647 11.0481 14.0011 11.0481Z"
                        fill="#618BDC"></path>
                </svg>
                <h3 :style="{ 'font-size': '25px' }">Owner</h3>
                <h5 :style="{
                    'text-decoration': 'underline',
                    color: 'purple',
                    'padding-top': '3px',
                }">
                    Show Percentage
                </h5>
            </div>
            <div id="last-row-middle2">
                <v-select label="Owners" v-model="Owners" :rules="[() => !!Owners || 'Owners is Required']"
                    variant="outlined" multiple :items="owners" border="black"></v-select>
                <v-text-field variant="outlined" label="Comments" v-model="Comments" border="black" required
                    :style="{ 'padding-right': '70px' }"></v-text-field>
            </div>
        </div>
        <div id="last">
            <div id="text">
                <svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <mask id="mask0_3401_93795" maskUnits="userSpaceOnUse" x="0" y="0" width="24" height="25"
                        style="mask-type: alpha">
                        <rect y="0.5" width="24" height="24" fill="#D9D9D9"></rect>
                    </mask>
                    <g mask="url(#mask0_3401_93795)">
                        <path
                            d="M4.5 20.9996V9.74967L12 4.10547L19.5 9.74967V20.9996H13.9038V14.3073H10.0961V20.9996H4.5Z"
                            fill="#D49A51"></path>
                    </g>
                </svg>
                <h3>Address Details</h3>
            </div>
            <div id="first-row-last">
                <v-text-field variant="outlined" label="Enter a Location" v-model="Location" border="black"
                    :style="{ 'width': '100px', 'padding-right': '10px' }"></v-text-field>
                <v-text-field variant="outlined" label="Address 1" v-model="Address1"
                    :rules="[() => !!Address1 || 'Address is Required']" border="black" required
                    :style="{ 'padding-right': '70px', 'width': '160px' }"></v-text-field>
            </div>
            <div id="middle-row-last">
                <div id="inner-middle-row1">
                    <v-text-field variant="outlined" label="Address2" v-model="Address2" border="black"
                        required></v-text-field>
                </div>
                <div id="inner-middle-row2">
                    <v-text-field variant="outlined" label="City" v-model="City" :style="{ 'width': '60px' }"
                        :rules="[() => !!City || 'City Required']" border="black" required></v-text-field>
                    <v-select label="State" variant="outlined" :items="states" v-model="state"
                        :rules="[() => !!state || 'State is Required']" return-object
                        :style="{ 'padding-right': '50px', 'padding-left': '10px' }" border="black"></v-select>
                </div>
            </div>
            <div id="last-row-last">
                <div id="inner-last-row1">
                    <v-text-field variant="outlined" label="Zip/Postal" v-model="ZipCode"
                        :rules="[() => !!ZipCode || 'Zip Code is Required']" border="black" required
                        :style="{ 'width': '60px', 'padding-right': '20px' }"></v-text-field>
                    <v-select label="Country" variant="outlined" :items="countries" v-model="country"
                        :rules="[() => !!country || 'Country is Required']" item-value="name"
                        :style="{ 'padding-right': '20px', width: '100px' }" border="black"></v-select>
                </div>
                <div id="inner-last-row2">
                    <v-text-field variant="outlined" label="Country Name" v-model="CountryName" border="black" required
                        :style="{ 'padding-right': '500px' }"></v-text-field>
                </div>
            </div>
        </div>
    </div>
</template>

<style scoped>
/* body{
 height: 100vh;
 width:100vw;
} */
#prakash {
    height: 100vh;
    width: 100vw;
}

#first {
    height: 15%;
    flex-direction: row;
    display: flex;
    border: 1px solid gray;
}

#add {
    width: 20%;
    display: flex;
    justify-content: center;
    align-items: center;
}

#inner {
    width: 50%;
}

#buttons {
    width: 30%;
    display: flex;
    /* justify-content: space-around; */
    align-items: center;
    flex-direction: row;
    margin-left: 300px;
    gap: 20px;
    /* padding: 50px;  */
    /* /* margin-left: 200px;  */
    /* margin: 30px; */
}

.btn {
    /* height: 30px; */
    color: purple;
    font-size: 15px;
    border: 1px solid purple;
    font-family: monospace;
    text-transform: inherit;
    /* width: 70px; */
}

.btn-new {
    /* height: 30px; */
    color: white;
    font-size: 15px;
    border: 1px solid purple;
    background: purple;
    font-family: monospace;
    text-transform: inherit;

    /* width: 70px; */
}

#middle-1 {
    height: 35%;
    display: flex;
    flex-direction: column;
    /* background: yellow; */

    /* background: yellow; */
}

#text {
    height: 20%;
    display: flex;
    align-items: center;
    margin-left: 70px;
    font-size: 20px;
    flex-direction: row;
    gap: 7px;
    margin-left: 50px;
}

#middle-first {
    display: flex;
    /* flex-direction: column; */
    justify-content: space-around;
    align-items: center;
    width: 100%;
    height: 25%;
    margin-left: -10px;
}

#first-row {
    display: flex;
    flex-direction: row;
    /* align-items: flex-start; */
    width: 95%;
    gap: 25px;
    /* margin-left: 40px; */
}

#middle-second {
    display: flex;
    flex-direction: row;
    /* justify-content: space-around; */
    /* align-items: center; */
    width: 100%;
    height: 25%;
    margin-left: 40px;
    gap: 25px;
}

#middle-second-1 {
    display: flex;
    flex-direction: row;
    justify-content: center;
    /* align-items: flex-start; */
    width: 437px;
    overflow: hidden;
    /* margin-left: 40px; */
}

#middle-last {
    display: flex;
    /* flex-direction: column; */
    /* justify-content: space-around; */
    align-items: center;
    width: 100%;
    height: 25%;
    margin-left: 40px;
    flex-direction: row;
    gap: 20px;
}

#last-row {
    display: flex;
    flex-direction: row;
    /* align-items: flex-start; */
    width: 47%;
    gap: 20px;
    /* margin-left: 40px; */
}

#last-row-inner {
    width: 49%;
    display: flex;
    flex-direction: row;
}

#last-row-1 {
    width: 48%;
    margin-right: 2px;
}

#text-new {
    padding-bottom: 50px;
    height: 5%;
    margin-left: 40px;
}

#middle-2 {
    height: 13%;
    width: 99%;
    display: flex;
    flex-direction: column;
    gap: 3px;
    /* justify-content: space-around; */
    /* margin-top: 10px; */
    margin-bottom: 10px;
    overflow: hidden;
    /* background: red; */
}

#first-row-middle2 {
    height: 40%;
    width: 100%;
    display: flex;
    flex-direction: row;
    gap: 10px;
    margin-left: 50px;
    padding-top: 20px;
    align-items: center;
}

#last-row-middle2 {
    height: 60%;
    width: 100%;
    display: flex;
    flex-direction: row;
    gap: 20px;
    margin-left: 40px;
    padding-top: 10px;
}

#last {
    height: 35%;
    display: flex;
    flex-direction: column;
    width: 99%;
    /* gap:2px */
    /* background: orange;   */
}

#first-row-last {
    display: flex;
    flex-direction: row;
    justify-content: center;
    margin-left: 40px;
    gap: 20px;
    width: 100%;
}

#middle-row-last {
    display: flex;
    flex-direction: row;
    /* justify-content: center; */
    margin-left: 40px;
    width: 100%;
    gap: 8px;
}

#inner-middle-row1 {
    width: 48%;
    margin-right: 10px;
}

#inner-middle-row2 {
    width: 50%;
    display: flex;
    flex-direction: row;
    gap: 10px;
}

#last-row-last {
    display: flex;
    flex-direction: row;
    /* justify-content: center; */
    margin-left: 40px;
    width: 100%;
}

#inner-last-row1 {
    width: 50%;
    display: flex;
    flex-direction: row;
    gap: 2px;
}

#inner-last-row2 {
    width: 50%;
    display: flex;
    justify-content: flex-start;
    margin-right: 35px;
}

.icon {
    height: 24px;
    width: 24px;
    margin-top: 20px;
}

.required-label::after {
    content: '*';
    color: red;
}
</style>
