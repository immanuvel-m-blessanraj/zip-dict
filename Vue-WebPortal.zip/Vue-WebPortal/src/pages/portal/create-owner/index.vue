<template>
  <div elevation="0" class="about">
    <v-container class=".custom-background" fluid>
      <v-row class="mt-1 ml-1 mb-2">
        <!-- <v-icon  class="mr-2" :color="iconColor">$vuetify</v-icon> -->
        <img
          src="@/assets/owner/contact.png"
          alt="Vuetify Logo"
          class="mr-2"
          style="width: 20px; height: 20px;"
        />
        <h4>{{data}}</h4>
      </v-row>
      <v-row>
        <v-col
          class="py-0"
          v-for="(item, index) in contactList"
          :key="index"
          cols="12"
          md="3"
          elevation="0"
        >
          <div elevation="0" v-if="item.type === 'TEXTFIELD'">
            <v-text-field
              :label="item.hint + (item.required ? ' *' : '')"
              variant="outlined"
              style="padding-top: 0px;
               padding-bottom: 0px"
            ></v-text-field>
          </div>
          <div elevation="0" v-else-if="item.type === 'DROPDOWN'">
            <v-select
              :items="item.dropDownList"
              variant="outlined"
              :label="item.label + (item.required ? ' *' : '')"
              item-text="title"
              item-value="title"
            ></v-select>
          </div>
        </v-col>
      </v-row>
      <v-row class="mt-1 ml-1 mb-2">
        <img
          src="@/assets/owner/address.png"
          alt="Vuetify Logo"
          class="mr-2"
          style=" width: 20px; height: 20px;"
        />
        <h4>Address Details</h4>
      </v-row>
      <v-row>
        <v-col
          class="py-0"
          v-for="(item, index) in addressList"
          :key="index"
          cols="12"
          md="3"
          elevation="0"
        >
          <div elevation="0" v-if="item.type === 'TEXTFIELD'">
            <v-text-field
              :label="item.hint + (item.required ? ' *' : '')"
              variant="outlined"
              style="padding-top: 0px;
               padding-bottom: 0px"
            ></v-text-field>
          </div>
          <div elevation="0" v-else-if="item.type === 'DROPDOWN'">
            <v-select
              :items="item.dropDownList"
              variant="outlined"
              :label="item.label + (item.required ? ' *' : '')"
              item-text="title"
              item-value="title"
            ></v-select>
          </div>
        </v-col>
      </v-row>
      <v-row class="mt-1 ml-1 mb-2">
        <img
          src="@/assets/owner/additional.png"
          alt="Vuetify Logo"
          class="mr-2"
          style=" width: 20px; height: 20px;"
        />
        <h4>Additional Details</h4>
      </v-row>
      <v-row>
        <v-col
          class="py-0"
          v-for="(item, index) in additionalList"
          :key="index"
          cols="12"
          md="3"
          elevation="0"
        >
          <div elevation="0" v-if="item.type === 'TEXTFIELD'">
            <v-text-field
              :label="item.hint + (item.required ? ' *' : '')"
              variant="outlined"
              style="padding-top: 0px;
               padding-bottom: 0px"
            ></v-text-field>
          </div>
          <div elevation="0" v-else-if="item.type === 'DROPDOWN'">
            <v-select
              :items="item.dropDownList"
              variant="outlined"
              :label="item.label + (item.required ? ' *' : '')"
              item-text="title"
              item-value="title"
            ></v-select>
          </div>
        </v-col>
      </v-row>
      <v-row>
        <v-checkbox class="checkbox-padding" label="Checkbox"></v-checkbox>
        <v-checkbox class="checkbox-padding" label="Checkbox"></v-checkbox>
        <v-checkbox class="checkbox-padding" label="Checkbox"></v-checkbox>
      </v-row>
    </v-container>
  </div>
</template>

<script>
import axios from "axios"

function fetchProduct() {
  return axios
    .get(
      "https://pz-qa-api.icaniotech.com/api/v1/utility-ms/codes/Business Type",
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6IkQ5MDY1NUE4OUI1MjcxQzRGMzBFRjM0NkZBQTBGNjY3IiwidHlwIjoiYXQrand0In0.eyJuYmYiOjE3MTQzNzcxMTksImV4cCI6MTcxNDM5ODcxOSwiaXNzIjoiaHR0cDovL3B6LXFhLWF1dGgtYXBpLmljYW5pb3RlY2guY29tIiwiY2xpZW50X2lkIjoiUHJvcGVydHlaYXJSZW1lbWJlck1lQ2xpZW50Iiwic3ViIjoiMTQyNyIsImF1dGhfdGltZSI6MTcxNDM3NzExOSwiaWRwIjoibG9jYWwiLCJzdWJzY3JpYmVySWQiOiIxMDMyIiwidGltZXpvbmUiOiJVUy9QYWNpZmljIiwicm9sZSI6IlN1YnNjcmlwdGlvbiBBZG1pbiIsImp0aSI6IkEyNDU0QjhGOTFDQzU3MTQ0RUE5N0JBQzkwQjgwQ0E5IiwiaWF0IjoxNzE0Mzc3MTE5LCJzY29wZSI6WyJvcGVuaWQiLCJwcm9wZXJ0eXphcl9hcGkiLCJvZmZsaW5lX2FjY2VzcyJdLCJhbXIiOlsicHdkIl19.VVkov-QAxElznOI1V2Zc2OKscSh0_GXcAgA6E1vEYEK2pWZA6h-zX1kWG5U4qS0zM5E80KemLBqo2Ln4aa0EQRMxEqBWsuUnw8dTNY-KyTV1Wzi1td4uRoyS7vpocnc-a9HgSmpEJhZ0VMzxpquBYni8sEaPNwY04Z9AfdicNr4oGJdZEleP3Gx8lso9i4Fv_3Yc4eUFlrCLFLfGhmcf5_tz9EUIbx9Sv0R39_tmsvMTWEI48U60K2AhW3d2AvpHgUY18ujWY1IofbkpGAsSJs0G2OQWMqlE9YDX0QNhXGntGe6RJxVhKwHcqZMUnggkKuyAawfXQu-Ii8dIcvVxjQ`
        }
      }
    );
}

const { isLoading, data: productData } = useQuery(["data"], fetchProduct);

export default {
  name: "AddOwner",
  mounted() {
    console.log("I am the developer");
    axios
      .get("https://dummyjson.com/products", {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6IkQ5MDY1NUE4OUI1MjcxQzRGMzBFRjM0NkZBQTBGNjY3IiwidHlwIjoiYXQrand0In0.eyJuYmYiOjE3MTQzNzcxMTksImV4cCI6MTcxNDM5ODcxOSwiaXNzIjoiaHR0cDovL3B6LXFhLWF1dGgtYXBpLmljYW5pb3RlY2guY29tIiwiY2xpZW50X2lkIjoiUHJvcGVydHlaYXJSZW1lbWJlck1lQ2xpZW50Iiwic3ViIjoiMTQyNyIsImF1dGhfdGltZSI6MTcxNDM3NzExOSwiaWRwIjoibG9jYWwiLCJzdWJzY3JpYmVySWQiOiIxMDMyIiwidGltZXpvbmUiOiJVUy9QYWNpZmljIiwicm9sZSI6IlN1YnNjcmlwdGlvbiBBZG1pbiIsImp0aSI6IkEyNDU0QjhGOTFDQzU3MTQ0RUE5N0JBQzkwQjgwQ0E5IiwiaWF0IjoxNzE0Mzc3MTE5LCJzY29wZSI6WyJvcGVuaWQiLCJwcm9wZXJ0eXphcl9hcGkiLCJvZmZsaW5lX2FjY2VzcyJdLCJhbXIiOlsicHdkIl19.VVkov-QAxElznOI1V2Zc2OKscSh0_GXcAgA6E1vEYEK2pWZA6h-zX1kWG5U4qS0zM5E80KemLBqo2Ln4aa0EQRMxEqBWsuUnw8dTNY-KyTV1Wzi1td4uRoyS7vpocnc-a9HgSmpEJhZ0VMzxpquBYni8sEaPNwY04Z9AfdicNr4oGJdZEleP3Gx8lso9i4Fv_3Yc4eUFlrCLFLfGhmcf5_tz9EUIbx9Sv0R39_tmsvMTWEI48U60K2AhW3d2AvpHgUY18ujWY1IofbkpGAsSJs0G2OQWMqlE9YDX0QNhXGntGe6RJxVhKwHcqZMUnggkKuyAawfXQu-Ii8dIcvVxjQ`
        }
      })
      .then(res => {
        console.log(res);
      });
    this.getStudent();
  },
  methods: {
    getStudent() {
      console.log("I am the developer2");
      axios
        .get(
          "https://pz-qa-api.icaniotech.com/api/v1/utility-ms/codes/Business Type",
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6IkQ5MDY1NUE4OUI1MjcxQzRGMzBFRjM0NkZBQTBGNjY3IiwidHlwIjoiYXQrand0In0.eyJuYmYiOjE3MTQzNzcxMTksImV4cCI6MTcxNDM5ODcxOSwiaXNzIjoiaHR0cDovL3B6LXFhLWF1dGgtYXBpLmljYW5pb3RlY2guY29tIiwiY2xpZW50X2lkIjoiUHJvcGVydHlaYXJSZW1lbWJlck1lQ2xpZW50Iiwic3ViIjoiMTQyNyIsImF1dGhfdGltZSI6MTcxNDM3NzExOSwiaWRwIjoibG9jYWwiLCJzdWJzY3JpYmVySWQiOiIxMDMyIiwidGltZXpvbmUiOiJVUy9QYWNpZmljIiwicm9sZSI6IlN1YnNjcmlwdGlvbiBBZG1pbiIsImp0aSI6IkEyNDU0QjhGOTFDQzU3MTQ0RUE5N0JBQzkwQjgwQ0E5IiwiaWF0IjoxNzE0Mzc3MTE5LCJzY29wZSI6WyJvcGVuaWQiLCJwcm9wZXJ0eXphcl9hcGkiLCJvZmZsaW5lX2FjY2VzcyJdLCJhbXIiOlsicHdkIl19.VVkov-QAxElznOI1V2Zc2OKscSh0_GXcAgA6E1vEYEK2pWZA6h-zX1kWG5U4qS0zM5E80KemLBqo2Ln4aa0EQRMxEqBWsuUnw8dTNY-KyTV1Wzi1td4uRoyS7vpocnc-a9HgSmpEJhZ0VMzxpquBYni8sEaPNwY04Z9AfdicNr4oGJdZEleP3Gx8lso9i4Fv_3Yc4eUFlrCLFLfGhmcf5_tz9EUIbx9Sv0R39_tmsvMTWEI48U60K2AhW3d2AvpHgUY18ujWY1IofbkpGAsSJs0G2OQWMqlE9YDX0QNhXGntGe6RJxVhKwHcqZMUnggkKuyAawfXQu-Ii8dIcvVxjQ`
            }
          }
        )
        .then(res => {
            this.
          console.log(res);
        });
    }
  },
  data() {
    const contactList = [
      {
        type: "DROPDOWN",
        label: "Owner Type",
        initialValue: "John",
        required: true,
        dropDownList: [
          {
            title: "John",
            subtitle: "Engineering"
          }
        ]
      },
      {
        type: "TEXTFIELD",
        label: "",
        hint: "Company Name",
        initialValue: ""
      },

      {
        type: "TEXTFIELD",
        label: "",
        required: true,
        hint: "First Name",
        initialValue: ""
      },
      {
        type: "TEXTFIELD",
        label: "",
        required: true,
        hint: "Last Name",
        initialValue: ""
      },

      {
        type: "TEXTFIELD",
        label: "",
        required: true,
        hint: "Primary Email",
        initialValue: ""
      },
      {
        type: "TEXTFIELD",
        label: "",
        hint: "AlterNate Email",
        initialValue: ""
      },
      {
        type: "TEXTFIELD",
        label: "Home Phone",
        hint: "Home Phone",
        initialValue: ""
      },
      {
        type: "TEXTFIELD",
        label: "Mobile Phone",
        hint: "Mobile Phone",
        initialValue: ""
      },
      {
        type: "TEXTFIELD",
        label: "",
        hint: "Fax",
        initialValue: ""
      },
      {
        type: "TEXTFIELD",
        label: "Work Phone",
        hint: "Work Phone",
        initialValue: ""
      },
      {
        type: "TEXTFIELD",
        label: "",
        hint: "Extension",
        initialValue: ""
      }
    ];

    const addressList = [
      {
        type: "TEXTFIELD",
        label: "",
        hint: "Enter a Location",
        initialValue: ""
      },
      {
        type: "TEXTFIELD",
        label: "",
        required: true,
        hint: "Address1",
        initialValue: ""
      },

      {
        type: "TEXTFIELD",
        label: "",
        hint: "Address2",
        initialValue: ""
      },
      {
        type: "TEXTFIELD",
        label: "",
        required: true,
        hint: "City",
        initialValue: ""
      },

      {
        type: "DROPDOWN",
        label: "State",
        hint: "State",
        required: true,
        initialValue: "",
        dropDownList: [
          {
            title: "John",
            subtitle: "Engineering"
          }
        ]
      },
      {
        type: "TEXTFIELD",
        label: "",
        hint: "Zip/Postal",
        required: true,
        initialValue: ""
      },
      {
        type: "DROPDOWN",
        label: "Country",
        hint: "Country",
        initialValue: "",
        dropDownList: [
          {
            title: "John",
            subtitle: "Engineering"
          }
        ]
      },
      {
        type: "TEXTFIELD",
        label: "",
        hint: "Country",
        initialValue: ""
      },
      {
        type: "TEXTFIELD",
        label: "",
        hint: "Comments",
        initialValue: ""
      }
    ];

    const additionalList = [
      {
        type: "TEXTFIELD",
        label: "",
        hint: "Display Name",
        initialValue: ""
      },
      {
        type: "TEXTFIELD",
        label: "",
        required: true,
        hint: "Business Entity",
        initialValue: ""
      },

      {
        type: "TEXTFIELD",
        label: "",
        hint: "Agreement Start",
        initialValue: ""
      },
      {
        type: "TEXTFIELD",
        label: "",
        required: true,
        hint: "Agreement End",
        initialValue: ""
      },

      {
        type: "DROPDOWN",
        label: "Tax Payer ID",
        hint: "Tax Payer ID",
        required: true,
        initialValue: "",
        dropDownList: [
          {
            title: "John",
            subtitle: "Engineering"
          }
        ]
      },
      {
        type: "TEXTFIELD",
        label: "",
        hint: "Reserve Account",
        required: true,
        initialValue: ""
      },
      {
        type: "DROPDOWN",
        label: "Reserve",
        hint: "Reserve",
        initialValue: "",
        dropDownList: [
          {
            title: "John",
            subtitle: "Engineering"
          }
        ]
      },
      {
        type: "TEXTFIELD",
        label: "Reserve",
        hint: "Reserve",
        initialValue: ""
      }
    ];

    return {
      iconColor: "primary", // You can set the color dynamically here
      contactList: contactList,
      addressList: addressList,
      additionalList: additionalList
    };
  }
};
</script>
<style scoped>
.custom-background {
  background-color: white;
  margin: 0;
  padding: 0;
}

.v-field__input {
  min-height: 45px !important;
  max-height: 20px !important;
}

.v-application .rounded-bl-xl {
  border-bottom-left-radius: 300px !important;
}

.v-application .rounded-br-xl {
  border-bottom-right-radius: 300px !important;
}

.checkbox-padding {
  padding-right: 100px;
  /* Adjust the value as needed */
}
</style>