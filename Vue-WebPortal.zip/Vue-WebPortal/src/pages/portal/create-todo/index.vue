<template>
    <CommonHeader title="Add ToDo" @cancel="handleCancel" />
    <CreateToDo />
</template>

<script>
import CommonHeader from "@/components/CommonHeader.vue";
import CreateToDo from "@/components/ToDoCreation/CreateToDo.vue";
import { routePath } from "@/utils/constant";

export default {
    components: {
        CreateToDo, CommonHeader
    }
    , methods: {
        handleCancel() {
            this.$router.push(routePath.portal);
        }
    }
}
</script>