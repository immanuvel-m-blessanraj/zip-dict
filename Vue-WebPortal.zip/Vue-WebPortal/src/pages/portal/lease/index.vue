<template>
  <v-card class="Container1">
    <div class="Container">
      <v-card-title class="primary">Leases</v-card-title>

      <fliter />
      <v-card-text>


        <Table />
      </v-card-text>
    </div>
  </v-card>

</template>



<script>
import Fliter from '@/components/Lease/Fliter.vue';
import Table from '@/components/Lease/Table.vue';

export default {
  components: {
    Fliter,
    // eslint-disable-next-line vue/no-reserved-component-names
    Table
  }
}
</script>

<style scoped>
.Container1 {
  margin: 50px;



}

.Container {
  margin: -100px;
  margin: auto;


}

.primary {
  color: blue;

}

.grey lighten-3 {
  background-color: aqua;
}

.search {
  background-color: #f0f0f0;


}
</style>