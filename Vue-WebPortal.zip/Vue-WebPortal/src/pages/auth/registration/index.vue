<template>
 

    <div class="split left">
      
        <img alt="Properties logo" src="../assets/properties.jpg" width="850" height="773">
        
      
    </div>
    
    <div class="split right" >
        <div style="height: 200px;">
          <!-- logo-->
    
        </div>
        <div style="height: 800px;">   
         <v-stepper model-value="1">
        <v-stepper-header>
          <v-stepper-item 
            title="User Information"
            value="1">
        
         </v-stepper-item>
    
          <v-divider>  
          </v-divider>
    
          <v-stepper-item
            title="Customer Information"
            value="2"
          ></v-stepper-item>
    
          <v-divider></v-divider>
    
          <v-stepper-item
            title="Plan Selection"
            value="3"
          ></v-stepper-item>
          <v-divider></v-divider>
    
          <v-stepper-item
            title="Plan Overview"
            value="4"
          ></v-stepper-item>
          <v-divider></v-divider>
    
          <v-stepper-item
            title="Application Customization"
            value="5"
          ></v-stepper-item>
          
        </v-stepper-header>
        <v-stepper-content>
                        <v-card color="#FFFFFF" class="mb-12" height="600px">
                            <v-card-text>
                                <v-form >
                                  <v-row>
                                    <v-col cols="6">
                                      <v-text-field
            v-model="firstName"
            :rules="rules"
            variant="outlined"
            label="First Name"
          ></v-text-field>
                                    </v-col>
                                    <v-col cols="6">
                                      <v-text-field
            v-model="lastName"
            :rules="rules"
            variant="outlined"
            label="Last Name"
          ></v-text-field>
                                    </v-col>
                                  </v-row>
                                  <v-row>
                                    <v-col cols="9">
                                      <v-text-field
            v-model="email"
            :rules="rules"
            variant="outlined"
            label="Email"
          ></v-text-field>
                                    </v-col>
                                    <v-col cols="3">
                                      <v-btn
            :loading="loading"
            class="mt-2"
            text="Verify"
            block
          ></v-btn>
                                    </v-col>
                                  </v-row>
          
          
         
         
          <v-text-field
            v-model="password"
            :rules="rules"
            variant="outlined"
            label="Password"
          ></v-text-field>
          <v-text-field
            v-model="confirmPassword"
            :rules="rules"
            variant="outlined"
            label="Confirm Password"
          ></v-text-field>
          
          <v-btn
            :loading="loading"
            class="mt-2"
            text="Next"
            type="submit"
            block
          ></v-btn>
    
                                </v-form>
                            </v-card-text>
                        </v-card>
                        
                    </v-stepper-content>
        
      </v-stepper>  
    </div> 
    </div>
    
    </template>
    
    <script>
    
    export default {
      data() {
        return {
          step: 1,
          formData: {
            field1: ''
          }
        };
      },
      methods: {
        nextStep() {
          this.step++;
        }
      }
    };
    
    </script>
    <style>
    body {
      font-family: Arial;
      color: rgb(0, 0, 0);
    }
    
    .split {
        height: 100%;
      width: 50%;
      position: fixed;
      z-index: 1;
      top: 0;
      overflow-x: hidden;
    }
    
    .left {
      left: 0;
      background-color: #fcfcfc;
    }
    
    .right {
      right: 0;
      background-color: #fcfcfc;
    }
    
    .v-stepper {
        background-color: #fffefe !important;
    }
    </style>