<template>
    <v-row no-gutters>
        <v-col order="1">
            <div>
                <v-img class="h-screen" cover src="@/assets/building.jpg">
                </v-img>
            </div>
        </v-col>
        <v-col order="12">
            <div class="login">
                <v-form v-model="form" @submit.prevent="onSubmit">
                    <h2 class="login-text-space">Log in</h2>
                    <h5 class="text-space">Log in to your account</h5>

                    <v-container>
                        <v-row>
                            <v-text-field label="Email address" variant="outlined" :readonly="loading"
                                :rules="[required]" density="comfortable"></v-text-field>
                        </v-row>
                        <v-row>
                            <v-text-field label="Type your password here"
                                :append-inner-icon="visible ? 'mdi-eye-off' : 'mdi-eye'"
                                :type="visible ? 'text' : 'password'" variant="outlined"
                                @click:append-inner="visible = !visible" :readonly="loading" :rules="[required]"
                                density="comfortable"></v-text-field>
                        </v-row>
                    </v-container>

                    <v-checkbox label="Keep me signed in" class="keep_me_sign"></v-checkbox>

                    <div class="login-btn">
                        <v-btn :disabled="!form" :loading="loading" color="#004E87" size="large" type="submit">Login
                        </v-btn>
                    </div>

                    <div class="sign-up">Don’t have an account? <a href="">Sign up</a></div>

                    <div><a href="">Forgot Password?</a></div>

                </v-form>
            </div>
        </v-col>
    </v-row>
</template>

<script>
import { routePath } from '@/utils/constant';


export default {
    data: () => ({
        form: false,
        email: null,
        password: null,
        loading: false,
        visible: false,

    }),

    methods: {
        onSubmit() {
            if (!this.form) return

            this.loading = true
            this.$router.push(routePath.lease);
            setTimeout(() => (this.loading = false), 2000)
        },
        required(v) {
            return !!v || 'Field is required'
        },
    },
}
</script>

<style scoped>
.login {
    margin-top: 180px;
    margin-left: 100px;
    margin-right: 100px;
}

.text-space {
    padding-bottom: 5%;
    margin: 0;
    font-size: 16px;
    font-weight: 600;
    font-family: Barlow, sans-serif;
    line-height: 1.334;
    font-weight: 400;
    color: #767676;
}

.text-field .v-field {
    height: 48px;
}

.keep_me_sign {
    height: 60px;
}

.v-btn {
    text-transform: none !important;
    font-weight: none !important;
}

.login-text-space {
    padding-bottom: 5%;
    font-weight: 600;
    font-size: 18px;
    font-family: Barlow, sans-serif;
}

.v-checkbox .v-selection-control {
    min-height: var(--v-input-control-height) !important;
}

.v-selection-control--density-default {
    --v-selection-control-size: 40px !important;
}

.sign-up {
    height: 30px;
}

.login-btn {
    height: 60px;
}

.v-input__control {
    height: 55px;
}
</style>