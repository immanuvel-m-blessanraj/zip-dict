<script setup>
import { routePath } from '@/utils/constant';
import { ref } from 'vue';
import { useRouter } from 'vue-router';

const drawer = ref(true);
const rail = ref(true);
const { push } = useRouter();

const navItems = [
  {
    title: 'Lease',
    value: routePath.lease
  },
  {
    title: 'Owner',
    value: routePath.createOwner
  },
  {
    title: 'Property',
    value: routePath.createProperty
  },
  {
    title: 'To-Do',
    value: routePath.createTodo
  },
  {
    title: 'Tenant',
    value: routePath.tenant
  },
]

const handleMenuItemClick = (routePath) => {
  push(routePath)
}


</script>
<template>
  <v-card>
    <v-layout>
      <v-navigation-drawer v-model="drawer" :rail="rail" permanent @click="rail = false">
        <v-list-item prepend-avatar="https://randomuser.me/api/portraits/men/85.jpg" title="John Leider" nav>
          <template v-slot:append>
            <v-btn icon="mdi-chevron-left" variant="text" @click.stop="rail = !rail"></v-btn>
          </template>
        </v-list-item>

        <v-divider></v-divider>

        <v-list density="compact" nav>
          <v-list-item v-for="(item, index) in navItems" v-bind:key="index" prepend-icon="mdi-account"
            :title="item.title" :value="item.value" @click="handleMenuItemClick(item.value)"></v-list-item>
        </v-list>
      </v-navigation-drawer>
      <v-main style="min-height: 100vh">
        <RouterView />
      </v-main>
    </v-layout>
  </v-card>
</template>