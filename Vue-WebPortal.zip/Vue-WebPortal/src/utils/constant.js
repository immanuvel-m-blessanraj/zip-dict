const portal = "/portal";
const auth = "/auth";

const routePath = {
  dashboard: "/dashboard",
  portal: portal,
  lease: `${portal}/lease`,
  tenant: `${portal}/tenant`,
  createTodo: `${portal}/create-todo`,
  createProperty: `${portal}/create-property`,
  createOwner: `${portal}/create-owner`,
  login: `${auth}/login`,
  registration: `${auth}/registration`,
};

export { routePath };
