import instance from "./instance";

const getRequest = (url, config) => {
    return instance.get(url, config);
};

const postRequest = (url, data, config) => {
    return instance.post(url, data, config);
};

const putRequest = (url, data, config) => {
    return instance.put(url, data, config);
};

const deleteRequest = (url, config) => {
    return instance.delete(url, config);
};

const patchRequest = (url, data, config) => {
    return instance.patch(url, data, config);
};

export { deleteRequest, getRequest, patchRequest, postRequest, putRequest };

