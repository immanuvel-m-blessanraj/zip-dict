
<template>
<v-app-bar :elevation="6" style="" >
  <v-app-bar-title class="portal-title">{{props.title}}</v-app-bar-title>
  <div class="btn-container">
  <v-btn density="default" class="cancel-btn capitalize-text" variant="outlined">Cancel</v-btn>
  <v-btn density="default" color="primary" class="save-btn capitalize-text"  variant="tonal" >Save</v-btn>
  </div>
</v-app-bar>
</template>


<script setup>
import { defineProps, } from 'vue';
  const props = defineProps({
  title:String // Define the 'message' prop with type String
})

</script>


<style scoped>
  
  .v-app-bar.v-toolbar {
  padding:1rem;
  box-shadow: none !important;
  border-bottom: 1px solid rgba(0, 0, 0, 0.12);
  }
.portal-title {
      font-size: 28px;
      font-weight: 600;
      line-height: 1.167;
}
 .btn-container {
  display: flex;
  gap:16px;
 }

 .capitalize-text {
    text-transform: capitalize
}

</style> 
