<template>
    <v-container fluid class="container_header_line">
        <v-row>
            <v-col cols="12" sm="12" md="6" class="d-flex align-center py-0">
                <v-card-text class="font-weight-bold text-h5">{{ title }}</v-card-text>
            </v-col>
            <v-col cols="12" sm="12" md="6" class="d-flex align-center py-0">
                <v-container class="d-flex justify-end ga-2 align-center">
                    <v-btn variant="outlined" class="capitalize-text cyan-lighten-2" @click="handleCancel">
                        Cancel
                    </v-btn>
                    <v-btn class="capitalize-text color-violet">
                        Save
                    </v-btn>
                    <v-btn class="capitalize-text color-violet">
                        Save and Set Remainder
                    </v-btn>
                </v-container>
            </v-col>
        </v-row>
    </v-container>
</template>

<style>
.capitalize-text {
    text-transform: capitalize
}

.container_header_line {
    border-bottom: 1px solid #b0a8a8;
}

button.color-violet {
    background: #9b089b;
    color: white;
}
</style>
<script>
export default {
    props: {
        title: String,
        
    },
    methods: {
        handleCancel() {
            const data = {   
                message: 'Cancellation initiated'
            };
            this.$emit('cancel', data);
        }
    }
}
</script>