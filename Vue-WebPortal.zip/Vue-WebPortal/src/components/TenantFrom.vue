
<template>
  <v-container class="mt-10" fluid>

    <v-row>
      <v-col cols="12" sm="12" md="12" class="d-flex align-center py-0">
        <v-icon color="blue-darken-2" icon="mdi-message-text" size="large"></v-icon>
        <v-card-text class="font-weight-bold text-h6">Personal Details</v-card-text>
      </v-col>
      <v-col cols="12" sm="4" md="3">
        <v-autocomplete label="Tenant Type" :items="['California', 'Colorado', 'Florida', 'Georgia', 'Texas', 'Wyoming']"
          variant="outlined"></v-autocomplete>
      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Company Name" variant="outlined"></v-text-field>
      </v-col>


      <v-col cols="12" sm="4" md="3">
        <v-text-field label="First Name" variant="outlined"></v-text-field>
      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Middle Name" variant="outlined"></v-text-field>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Last Name" variant="outlined"></v-text-field>
      </v-col>
    </v-row>


    <v-row>
      <v-col cols="12" sm="12" md="12" class="d-flex align-center py-0">
        <v-icon color="blue-darken-2" icon="mdi-domain" size="large"></v-icon>
        <v-card-text class="font-weight-bold text-h6">Additional Details</v-card-text>
      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Date of Birth" variant="outlined" type="date"></v-text-field>

      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Social Security #" variant="outlined"></v-text-field>
      </v-col>


      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Email" variant="outlined"></v-text-field>
      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Alternative Email" variant="outlined"></v-text-field>
      </v-col>
    </v-row>

    <v-row>
      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Driver License" variant="outlined"></v-text-field>

      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-text-field label="DL/ID State" variant="outlined"></v-text-field>
      </v-col>


      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Status" variant="outlined"></v-text-field>
      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Primary Language" variant="outlined"></v-text-field>
      </v-col>
    </v-row>


    <v-row>
      <v-col cols="12" sm="12" md="12" class="d-flex align-center py-0">
        <v-icon color="blue-darken-2" icon="mdi-email" size="large"></v-icon>
        <v-card-text class="font-weight-bold text-h6">Contact Details</v-card-text>
      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Home Phone" variant="outlined" type="number"></v-text-field>

      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Mobile Phone" variant="outlined" type="number"></v-text-field>
      </v-col>


      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Work Phone" variant="outlined" type="number"></v-text-field>
      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Fax" variant="outlined"></v-text-field>
      </v-col>
    </v-row>

    <v-row>
      <v-col col="12" sm="12">
        <v-checkbox label="Enter Guarantor Details"></v-checkbox>
      </v-col>
    </v-row>

    <v-row>
      <v-col cols="12" sm="12" md="12" class="d-flex align-center py-0">
        <v-icon color="blue-darken-2" icon="mdi-message-reply-text" size="large"></v-icon>
        <v-card-text class="font-weight-bold text-h6">Emergency Contact Details</v-card-text>
      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Contact Name" variant="outlined"></v-text-field>

      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Relationship" variant="outlined"></v-text-field>
      </v-col>


      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Email" variant="outlined"></v-text-field>
      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Phone" variant="outlined"></v-text-field>
      </v-col>
    </v-row>

    <v-row>
      <v-col cols="12" sm="8" md="6">
        <v-text-field label="Location" variant="outlined"></v-text-field>
      </v-col>

      <v-col cols="12" sm="8" md="6">
        <v-text-field label="Address 1" variant="outlined"></v-text-field>
      </v-col>
    </v-row>

    <v-row>
      <v-col cols="12" sm="8" md="6">
        <v-text-field label="Address 2" variant="outlined"></v-text-field>

      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-text-field label="City" variant="outlined"></v-text-field>
      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-text-field label="State" variant="outlined"></v-text-field>
      </v-col>

    </v-row>


    <v-row>
      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Zip/Postal" variant="outlined"></v-text-field>

      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Country" variant="outlined"></v-text-field>
      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-text-field label="County" variant="outlined"></v-text-field>
      </v-col>
    </v-row>


    <v-row>
      <v-col cols="12" sm="12" md="12" class="d-flex align-center py-0">
        <v-icon color="blue-darken-2" icon="mdi-clipboard-account" size="large"></v-icon>
        <v-card-text class="font-weight-bold text-h6">Other Details</v-card-text>
      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-checkbox label="Smoker"></v-checkbox>

      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-checkbox label="Email Opt Out"></v-checkbox>
      </v-col>


      <v-col cols="12" sm="4" md="3">
        <v-checkbox label="Can Access Portal"></v-checkbox>
      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-checkbox label="Can Access App"></v-checkbox>
      </v-col>
    </v-row>

    <v-row>
      <v-col cols="12" sm="4" md="3">
        <v-checkbox label="Can Rate Vendors"></v-checkbox>

      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-checkbox label="Do Not Charge Late Fees"></v-checkbox>
      </v-col>


      <v-col cols="12" sm="4" md="3">
        <v-checkbox label="Do Not Accept Checks"></v-checkbox>
      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-checkbox label="Allow Partial Payment"></v-checkbox>
      </v-col>
    </v-row>

    <v-row>
      <v-col cols="12" sm="4" md="3">
        <v-checkbox label="Apply Sales Tax"></v-checkbox>
      </v-col>
    </v-row>


    <v-row>
      <v-col cols="12" sm="6" md="6">
        <v-text-field label="Comments" variant="outlined"></v-text-field>

      </v-col>

      <v-col cols="12" sm="6" md="6">
        <v-text-field label="RV Length" variant="outlined"></v-text-field>
      </v-col>

    </v-row>

    <v-row>
      <v-col cols="12" sm="6">
        <v-text-field label="RV Type" variant="outlined"></v-text-field>
      </v-col>
    </v-row>


    <v-row>
    <v-col cols="12" sm="12" md="12" class="d-flex align-center py-0">
        <v-icon color="blue-darken-2" icon="mdi-hospital-building" size="large"></v-icon>
        <v-card-text class="font-weight-bold text-h6">Policy Details</v-card-text>
    </v-col>

    <v-col cols="12" sm="8" md="6">
      <v-text-field label="Insurance Provider" variant="outlined" ></v-text-field>

    </v-col>

    <v-col cols="12" sm="4" md="3">
      <v-text-field label="Policy #" variant="outlined" ></v-text-field>
    </v-col>


    <v-col cols="12" sm="4" md="3">
      <v-text-field label="Expiration Date" variant="outlined" type="date"></v-text-field>
    </v-col>

    </v-row>

    <v-row>
      <v-col cols="12" sm="12" md="12" class="d-flex align-center py-0">
        <v-icon color="blue-darken-2" icon="mdi-city" size="large"></v-icon>
        <v-card-text class="font-weight-bold text-h6">Business Details</v-card-text>
      </v-col>
      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Type Of Entity" variant="outlined" ></v-text-field>

      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-text-field label="State of Incorporation" variant="outlined" ></v-text-field>
      </v-col>


      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Tax ID Number" variant="outlined" type="number"></v-text-field>
      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Business Type" variant="outlined"></v-text-field>
      </v-col>
    </v-row>

    <v-row>
      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Ownership Percentage" variant="outlined" ></v-text-field>

      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Tenant Title" variant="outlined" ></v-text-field>
      </v-col>


      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Driver's Issued Date" variant="outlined" type="date"></v-text-field>
      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Driver's Expiration Date" variant="outlined"></v-text-field>
      </v-col>
    </v-row>


   



    <v-row>
      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Gross Revenue" variant="outlined" ></v-text-field>

      </v-col>

      <v-col cols="12" sm="4" md="3">
        <v-text-field label="Gross Expense" variant="outlined" ></v-text-field>
      </v-col>

    </v-row>

  </v-container>
</template>


<script setup>


</script>


<style scoped></style> 
