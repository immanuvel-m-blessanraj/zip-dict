<template>
  <v-data-table-server :headers="headers" :items="serverItems" :items-length="totalItems" :loading="loading"
    item-value="name" show-select @update:options="loadItems" class="custom-data-table"></v-data-table-server>
</template>
<script>
const desserts = [
  {
    name: 'feb22',
    calories: 'feb22property',
    fat: 'unit',
    carbs: 'uniy',
    protein: 'subak',
    iron: '1',
  },
  {
    name: 'Bysy',
    calories: 'buid',
    fat: 'checkun',
    carbs: 'abim',
    protein: 0.0,
    iron: '0',
  },
  // Add more dessert data as needed
];

const FakeAPI = {
  async fetch({ page, itemsPerPage, sortBy }) {
    return new Promise(resolve => {
      setTimeout(() => {
        const start = (page - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        const items = desserts.slice();

        if (sortBy.length) {
          const sortKey = sortBy[0].key;
          const sortOrder = sortBy[0].order;
          items.sort((a, b) => {
            const aValue = a[sortKey];
            const bValue = b[sortKey];
            return sortOrder === 'desc' ? bValue - aValue : aValue - bValue;
          });
        }

        const paginated = items.slice(start, end);

        resolve({ items: paginated, total: items.length });
      }, 500);
    });
  },
};

export default {
  data: () => ({
    itemsPerPage: 5,
    headers: [
      {
        title: 'Id',
        align: 'start',
        sortable: false,
        key: 'name',
      },
      { title: 'Property', key: 'calories', align: 'end' },
      { title: 'Building', key: 'fat', align: 'end' },
      { title: 'Unit', key: 'carbs', align: 'end' },
      { title: 'Tenant(s)', key: 'protein', align: 'end' },
      { title: 'StartDate', key: 'iron', align: 'end' },
      { title: 'EndDate', key: 'iron', align: 'end' },
      { title: 'Rent', key: 'iron', align: 'end' },
      { title: 'Type', key: 'iron', align: 'end' },
      { title: 'Lease Doucment', key: 'iron', align: 'end' },

    ],
    serverItems: [],
    loading: true,
    totalItems: 0,
  }),
  methods: {
    loadItems({ page, itemsPerPage, sortBy }) {
      this.loading = true;
      FakeAPI.fetch({ page, itemsPerPage, sortBy }).then(({ items, total }) => {
        this.serverItems = items;
        this.totalItems = total;
        this.loading = false;
      });
    },
    // Method to handle tab change
    handleTabChange() {
      // Clear existing data
      this.serverItems = [];
      this.totalItems = 0;
      // Load data for the selected tab
      this.loadItems({ page: 1, itemsPerPage: this.itemsPerPage, sortBy: [] });
    },
  },
  mounted() {
    // Load initial data
    this.loadItems({ page: 1, itemsPerPage: this.itemsPerPage, sortBy: [] });
  },
};
</script>

<style>
/* Custom styles */
.custom-data-table {
  border: 1px solid #ccc;
  padding: 0;
}

.custom-data-table th {
  background-color: #f0f0f0;
}

.custom-data-table td {
  font-weight: bold;
}
</style>
