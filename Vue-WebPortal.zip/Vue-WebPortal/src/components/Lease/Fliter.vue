<template>
  <v-row class="flex" >
    <v-col>
      <v-text-field
        class="textfield"
        :loading="loading"
        prepend-inner-icon="mdi-magnify"
        dense
        label="Search templates"
        variant="solo"
        hide-details
        single-line
        @click:append-inner="onClick"
      ></v-text-field>
    </v-col>
     <v-col>
      <!-- <v-text-field
        class="textfield1"
        :loading="loading"
        prepend-inner-icon="mdi-magnify"
        dense
        label="Fliter"
        variant="solo"
        hide-details
        single-line
        @click:append-inner="onClick"
      ></v-text-field> -->
      <v-autocomplete
 class="textfield1"
        :loading="loading"
        prepend-inner-icon="mdi-magnify"
        dense
        label="Fliter"
        variant="solo"
        hide-details
        single-line
        @click:append-inner="onClick"
  :items="['Property','Building','Unit','Tenant','StartDate','EndDate','Rent','Type','Lease Doucment']"
  
></v-autocomplete>
    </v-col>
      <v-col>
      <v-text-field
        class="textfield2"
        :loading="loading"
        prepend-inner-icon="mdi-magnify"
        dense
        label="Sort"
        variant="solo"
        hide-details
        single-line
        @click:append-inner="onClick"
      ></v-text-field>
    </v-col>
     <!-- <v-col>
      <v-text-field
        class="textfield"
        :loading="loading"
        prepend-inner-icon="mdi-magnify"
        dense
        label="Search templates"
        variant="solo"
        hide-details
        single-line
        @click:append-inner="onClick"
      ></v-text-field>
    </v-col> -->  
  </v-row>
</template>
<style scoped>
.textfield{

  padding-left: 5;
  
}
.flex{
  display: flex;
align-content: flex-end;
  margin-left: 600px;
}
.textfield1{
   padding-left: 25px;

  

}
.textfield2{
   padding-left: 20px;

  padding-right: 50px;

}

</style>