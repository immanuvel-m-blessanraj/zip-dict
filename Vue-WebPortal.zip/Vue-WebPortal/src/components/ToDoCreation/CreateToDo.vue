<template>
    <v-container fluid>

        <v-row>
            <v-col cols="12" sm="12" md="12" class="d-flex align-center py-0">
                <v-icon color="blue-darken-2" icon="mdi-message-text" size="large"></v-icon>
                <v-card-text class="font-weight-bold text-h6">To Do</v-card-text>
            </v-col>
            <v-col cols="12" sm="6" class="py-0">
                <v-text-field label="Subject" variant="outlined" />
            </v-col>
            <v-col cols="12" sm="3" class="py-0">
                <v-text-field label="Start Date" variant="outlined" type="date" />
            </v-col>
            <v-col cols="12" sm="3" class="py-0">
                <v-text-field label="Due Date" variant="outlined" type="date" />
            </v-col>
            <v-col cols="12" sm="3" class="py-0">
                <v-autocomplete clearable label="Assigned To" :items="assignedTo" variant="outlined"></v-autocomplete>
            </v-col>
        </v-row>
        <v-row>
            <v-col cols="12" sm="12" md="12" class="d-flex align-center py-0">
                <HomeIco />
                <v-card-text class="font-weight-bold text-h6">Details</v-card-text>
            </v-col>
        </v-row>
        <v-row>
            <v-col cols="12" sm="3" class="py-0" v-for="(item, index) in detailsArr" :key="index">
                <v-autocomplete :label="item.label" clearable :items="item.list" variant="outlined">
                </v-autocomplete>
            </v-col>

        </v-row>
        <v-row>
            <v-col cols="12" sm="12" md="12" class="d-flex align-center py-0">
                <v-icon color="green-darken-2" icon="mdi-domain" size="large"></v-icon>
                <v-card-text class="font-weight-bold text-h6">Related To</v-card-text>

            </v-col>
        </v-row>
        <v-row>
            <v-col cols="12" sm="3" class="py-0" v-for="(item, index) in relatedToArr" :key="index">
                <v-autocomplete :label="item.label" clearable :items="item.list" variant="outlined">
                </v-autocomplete>
            </v-col>
        </v-row>
        <v-row>
            <v-col cols="12" sm="12" md="12" class="d-flex align-center py-0">
                <v-icon color="orange-darken-2" icon="mdi-arrow-up-bold-box-outline" size="large"></v-icon>
                <v-card-text class="font-weight-bold text-h6">Description</v-card-text>

            </v-col>
        </v-row>
        <v-row>
            <v-col cols="12" sm="3" class="py-0">
                <v-textarea clearable label="Description" variant="outlined"></v-textarea>
            </v-col>
        </v-row>
    </v-container>
</template>

<script>
import HomeIco from "@/assets/Icons/HomeIco";
export default {
    components: {
        HomeIco
    },
    data() {
        return {
            assignedTo: ['Jennie', 'Zoya', 'Lisa', 'Jisoo', 'Rose',],
            detailsArr: [{
                label: "Type",
                list: ['Email', 'General', 'Key', 'Maintenance', 'Others', 'Meeting'],
            }, {
                label: "Status",
                list: ['To Do', 'Completed', 'In progress'],
            }, {
                label: "Priority",
                list: ['High', 'Normal', 'Medium', 'Urgent'],
            }],
            relatedToArr: [
                {
                    label: "Owner",
                    list: ['Selva Ananthi', 'Ananthi', 'Zoya', 'Maya', 'Taehyung', 'JK'],
                },
                {
                    label: "Property",
                    list: ['Hype', 'Property 1', 'Property 2', 'Property 3', 'Property 4', 'Property 5'],
                },
                {
                    label: "Building",
                    list: ['Building 1', 'Building 2', 'Building 3', 'Building 4', 'Building 5', 'Building 6'],
                },
                {
                    label: "Unit",
                    list: ['Unit', 'Hype', 'Pink', 'Unit 3', 'Unit 3', 'Unit 5'],
                },
                {
                    label: "Applicant / Tenant",
                    list: ['Jennie', 'Zoya', 'Lisa', 'Jisoo', 'Rose',],
                },
            ],

        }
    }
}
</script>