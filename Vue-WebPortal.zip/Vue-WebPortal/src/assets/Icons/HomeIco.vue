<template>
  <svg width="22" height="17" viewBox="0 0 22 17" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M16.1154 5.38461H17.8846V3.61541H16.1154V5.38461ZM16.1154 9.38461H17.8846V7.61541H16.1154V9.38461ZM16.1154 13.3846H17.8846V11.6154H16.1154V13.3846ZM0.5 17V7.75003L6.99998 3.11543L13.5 7.75003V17H8.92305V11.4615H5.0769V17H0.5ZM15.5 17V6.75003L9.1923 2.20968V3.05176e-05H21.5V17H15.5Z"
      fill="#789F48"></path>
  </svg>
</template>

<script>
export default {
  name: 'HomeIco'
}
</script>

<style scoped></style>
