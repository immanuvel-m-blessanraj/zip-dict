// import 'dart:convert';

// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';

// class DictionaryScreen extends StatefulWidget {
//   const DictionaryScreen({super.key});

//   @override
//   State<DictionaryScreen> createState() => _DictionaryScreenState();
// }

// class _DictionaryScreenState extends State<DictionaryScreen> {
//   final TextEditingController _searchController = TextEditingController();
//   final List<String> _searchHistory = [];
//   final Map<String, String> _dictionary = {};

//   @override
//   void initState() {
//     super.initState();
//     _loadDictionary();
//   }

//   Future<void> _loadDictionary() async {
//     try {
//       String jsonString = await rootBundle.loadString('assets/json/meanings.json');
//       final Map<String, dynamic> data = json.decode(jsonString);
//       final List<dynamic> words = data['words'];

//       for (var entry in words) {
//         _dictionary[entry['word']] = entry['meaning'];
//       }
//     } catch (e) {
//       print('Error loading dictionary: $e');
//     }
//   }

//   void _searchWord(String word) {
//     if (word.isEmpty) return;

//     if (!_searchHistory.contains(word)) {
//       setState(() {
//         _searchHistory.insert(0, word);
//       });
//     }

//     _searchController.clear();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Center(
//       child: Container(
//         width: 550,
//         height: 500,
//         decoration:
//             BoxDecoration(border: Border.all(color: Colors.blue.shade50)),
//         child: Scaffold(
//           backgroundColor: const Color.fromRGBO(30, 130, 174, 1),
//           appBar: AppBar(
//             backgroundColor: Colors.blue.shade50,
//             title: Row(
//               children: [
//                 Container(
//                   margin: const EdgeInsets.all(2),
//                   height: 40,
//                   width: 40,
//                   decoration: const BoxDecoration(
//                     color: Colors.blue,
//                     borderRadius: BorderRadius.all(Radius.circular(10)),
//                   ),
//                   child: const Center(
//                     child: Text(
//                       'Æ',
//                       style:
//                           TextStyle(fontSize: 18, fontWeight: FontWeight.w400),
//                     ),
//                   ),
//                 ),
//                 Container(
//                   margin: const EdgeInsets.all(2),
//                   height: 40,
//                   width: 40,
//                   decoration: const BoxDecoration(
//                     color: Colors.red,
//                     borderRadius: BorderRadius.all(Radius.circular(10)),
//                   ),
//                   child: const Center(
//                     child: Text(
//                       'A',
//                       style:
//                           TextStyle(fontSize: 18, fontWeight: FontWeight.w400),
//                     ),
//                   ),
//                 ),
//                 Container(
//                   margin: const EdgeInsets.all(2),
//                   height: 40,
//                   width: 40,
//                   decoration: const BoxDecoration(
//                     color: Colors.yellow,
//                     borderRadius: BorderRadius.all(Radius.circular(10)),
//                   ),
//                   child: const Center(
//                     child: Text(
//                       'அ',
//                       style: TextStyle(
//                           fontSize: 18,
//                           fontWeight: FontWeight.w400,
//                           fontFamily: "MeeraInimai-Regular"),
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//             actions: [
//               IconButton(
//                 onPressed: () {},
//                 icon: const FaIcon(
//                   FontAwesomeIcons.trashCan,
//                   size: 15,
//                 ),
//               ),
//               IconButton(
//                 onPressed: () {},
//                 icon: const Icon(Icons.copy_outlined, size: 15),
//               ),
//             ],
//           ),
//           body: Column(
//             children: [
//               SizedBox(
//                 height: 392,
//                 child: Expanded(
//                   child: ListView.builder(
//                     itemCount: _searchHistory.length,
//                     itemBuilder: (context, index) {
//                       final word = _searchHistory[index];
//                       final meaning = _dictionary[word] ?? 'Meaning not found';
//                       return ListTile(
//                         title: Text(word),
//                         subtitle: Text(meaning),
//                       );
//                     },
//                   ),
//                 ),
//               ),
//               Row(
//                 children: [
//                   Container(
//                       padding: const EdgeInsets.only(left: 10),
//                       width: 500,
//                       height: 50,
//                       color: Colors.white,
//                       child: TextField(
//                         controller: _searchController,
//                         decoration: const InputDecoration(
//                           border: InputBorder.none,
//                           hintText: 'TYPE HERE',
//                           hintStyle: TextStyle(
//                               fontSize: 25, fontWeight: FontWeight.normal),
//                         ),
//                       )),
//                   Container(
//                       color: const Color.fromRGBO(13, 202, 240, 1),
//                       width: 48,
//                       height: 50,
//                       child: IconButton(
//                           onPressed: () {
//                             _searchWord(_searchController.text);
//                           },
//                           icon: const FaIcon(
//                             FontAwesomeIcons.paperPlane,
//                             color: Colors.white,
//                             size: 20,
//                           )))
//                 ],
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
