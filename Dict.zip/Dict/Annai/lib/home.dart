import 'dart:math';

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:web_view_app/utils/screen_size.dart';
import 'package:web_view_app/word.dart';

import 'links.dart';
import 'strings.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

_launchURL(props) async {
  final Uri url = Uri.parse(props);
  if (!await launchUrl(url)) {
    throw Exception('Could not launch $url');
  }
}

bool _isDesktopScreen = false, _isTabScreen = false, _isMobileScreen = false;

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    bool isDesktopScreen = ScreenSize.isDesktopScreen(context);
    bool isTabScreen = ScreenSize.isTabScreen(context);
    bool isMobileScreen = ScreenSize.isMobileScreen(context);
    setState(() {
      _isDesktopScreen = isDesktopScreen;
      _isTabScreen = isTabScreen;
      _isMobileScreen = isMobileScreen;
    });
    return Scaffold(
      backgroundColor: Colors.white,
      // appBar: PreferredSize(
      //   preferredSize: const Size.fromHeight(90),
      //   child: Container(
      //     padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 80),
      //     child:
      //      AppBar(
      //       shadowColor: Colors.grey,
      //       toolbarHeight: 90,
      //       title: Row(
      //         children: [
      //           SizedBox(
      //             width: 100,
      //             height: 80,
      //             child: IconButton(
      //                 onPressed: () {},
      //                 icon: Image.asset(
      //                   'assets/logo.png',
      //                   fit: BoxFit.fill,
      //                 )),
      //           ),
      //           Text(
      //             appNameTamil,
      //             style: const TextStyle(
      //                 fontFamily: "MeeraInimai-Regular", fontSize: 16,fontWeight: FontWeight.bold),
      //           ),
      //         ],
      //       ),
      //       backgroundColor: Colors.white,
      //       actions: [
      //         IconButton(
      //           onPressed: () {
      //             _launchURL(facebookUrl);
      //           },
      //           icon: const Icon(Icons.facebook),
      //         ),
      //         IconButton(
      //           onPressed: () {
      //             _launchURL(whatsappUrl);
      //           },
      //           icon: const FaIcon(FontAwesomeIcons.whatsapp),
      //         ),
      //         IconButton(
      //           onPressed: () {
      //             _launchURL(twitterUrl);
      //           },
      //           icon: const FaIcon(FontAwesomeIcons.twitter),
      //         ),
      //         IconButton(
      //           onPressed: () {
      //             _launchURL(instaUrl);
      //           },
      //           icon: const FaIcon(FontAwesomeIcons.instagram),
      //         ),
      //         IconButton(
      //           onPressed: () {
      //             _launchURL(emailUrl);
      //           },
      //           icon: const Icon(Icons.mail_outline),
      //         ),
      //       ],
      //     ),
      //   ),
      // ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (!isMobileScreen)
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: EdgeInsets.only(left: 100),
                    child: Row(
                      children: [
                        logo(),
                        annai(),
                      ],
                    ),
                  ),
                  if (!isMobileScreen) socialMedia(),
                ],
              ),
            if (isMobileScreen) logo(),
            if (isMobileScreen) annai(),
            if (isMobileScreen) socialMedia(),
            SizedBox(
                width: double.infinity,
                child: Image.asset(
                  'assets/backOne.png',
                  fit: BoxFit.fitWidth,
                )),
            Container(
              decoration: const BoxDecoration(
                color: Color.fromRGBO(30, 130, 174, 1),
              ),
              child: Column(
                children: [
                  const DictionaryScreen(),
                  SizedBox(
                      width: double.infinity,
                      child: Image.asset('assets/backLast.png',
                          fit: BoxFit.fitWidth)),
                  Container(
                    width: double.infinity,
                    color: Colors.white,
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            IntrinsicWidth(
                              child: Text(
                                developerDetail,
                                style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500,
                                    overflow: TextOverflow.visible),
                              ),
                            ),
                            SizedBox(
                              width: MediaQuery.of(context).size.width * 0.8,
                              child: Text(
                                copyFooter,
                                style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500,
                                    overflow: TextOverflow.visible),
                              ),
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            TextButton(
                                onPressed: () {
                                  _launchURL(developerWeb);
                                },
                                child: Text(
                                  developerWebsite,
                                  style: const TextStyle(color: Colors.black54),
                                )),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget logo() {
    return SizedBox(
      width: 100,
      height: 80,
      child: IconButton(
          onPressed: () {},
          icon: Image.asset(
            'assets/logo.png',
            fit: BoxFit.fill,
          )),
    );
  }

  Widget annai() {
    return Text(
      appNameTamil,
      style: const TextStyle(
          fontFamily: "MeeraInimai-Regular",
          fontSize: 16,
          fontWeight: FontWeight.bold),
    );
  }

  Widget socialMedia() {
    return Padding(
      padding: EdgeInsets.only(right: _isMobileScreen ? 0 : 100),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          IconButton(
            onPressed: () {
              _launchURL(facebookUrl);
            },
            icon: const Icon(Icons.facebook),
          ),
          IconButton(
            onPressed: () {
              _launchURL(whatsappUrl);
            },
            icon: const FaIcon(FontAwesomeIcons.whatsapp),
          ),
          IconButton(
            onPressed: () {
              _launchURL(twitterUrl);
            },
            icon: const FaIcon(FontAwesomeIcons.twitter),
          ),
          IconButton(
            onPressed: () {
              _launchURL(instaUrl);
            },
            icon: const FaIcon(FontAwesomeIcons.instagram),
          ),
          IconButton(
            onPressed: () {
              _launchURL(emailUrl);
            },
            icon: const Icon(Icons.mail_outline),
          ),
        ],
      ),
    );
  }
}
