String whatsappUrl='https://api.whatsapp.com/send?text=translate%0ahttps://ordbok.annai.no/';

String facebookUrl='https://www.facebook.com/sharer/sharer.php?u=https%3A//ordbok.annai.no/';

String instaUrl='https://instagram.com/';

String twitterUrl='https://twitter.com/intent/tweet?text=https%3A//ordbok.annai.no/';

String emailUrl='https://ordbok.annai.no/get-request/';

String developerWeb='https://www.kavadi.in/';