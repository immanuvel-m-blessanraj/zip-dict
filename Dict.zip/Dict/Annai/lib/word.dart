import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'utils/screen_size.dart';

class DictionaryScreen extends StatefulWidget {
  const DictionaryScreen({super.key});

  @override
  State<DictionaryScreen> createState() => _DictionaryScreenState();
}

class _DictionaryScreenState extends State<DictionaryScreen> {
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _controller = ScrollController();
  final List _searchHistory = [];
  final List _searchword = [];

  static const Map<String, dynamic> dictionay = {
    "and": [
      {"ta": "மற்றும் ; உம்", "no": "Og"},
      {"ta": "வாத்து", "en": "Duck"},
      {"ta": "மற்றும்", "no": "Samt"},
      {"ta": "ஆவி", "en": "Spirit"},
      {"ta": "முக்குளிப்பு", "en": "Duck"},
      {"ta": "உம்", "no": "Og"},
      {"ta": "எரிநறா", "en": "Spirit"},
      {"ta": "நிமித்தனமமாக", "no": "Og"},
      {"ta": "மற்றும்", "no": "Og"},
      {"ta": "மாணிக்கவாசகர்", "no": "Og"}
    ],
    "மற்றும்": [
      {"no": "Samt", "en": "And"},
      {"no": "En gang til", "en": "Again"},
      {"no": "Og", "en": "And"},
      {"no": "I tillegg", "en": "Besides"},
      {"no": "Et", "en": "Et"}
    ],
    "தமிழ்": [
      {
        "no": "Primær Klassisk Språk I Verden",
        "en": "Primary Classical Language Of The World"
      },
      {"no": "Tamil", "en": "Tamil"},
      {"no": "Norsk", "en": "Norsk"}
    ],
    "tamil": [
      {"ta": "தமிழ்", "en": "Tamil"},
      {"ta": "தமிழர்", "en": "Tamil"},
      {"ta": "தமிழ்மொழி", "en": "Tamil"}
    ]
  };

  @override
  void initState() {
    super.initState();
  }

  void _searchWord(String word) {
    if (word.isEmpty) return;
    try {
      List? dict = dictionay[word];

      if (dict != null) {
        _searchword.add(word);
        _searchHistory.add(dict);
        setState(() {});
        if (_searchword.length != 1) {
          _scrollDown();
        }
      } else {
        _searchword.add(word);
        _searchHistory.add([
          {"no": "No result found"},
        ]);
        setState(() {});
        if (_searchword.length != 1) {
          _scrollDown();
        }
        debugPrint('No result found');
      }
    } catch (e) {
      debugPrint('Error loading dictionary: $e');
    }
    _searchController.clear();
  }

// This is what you're looking for!
  void _scrollDown() {
    _controller.animateTo(
      _controller.position.maxScrollExtent + 300,
      duration: const Duration(milliseconds: 200),
      curve: Curves.fastOutSlowIn,
    );
  }

  @override
  Widget build(BuildContext context) {
    bool isDesktopScreen = ScreenSize.isDesktopScreen(context);
    bool isTabScreen = ScreenSize.isTabScreen(context);
    bool isMobileScreen = ScreenSize.isMobileScreen(context);
    return SelectionArea(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20),
        width: isMobileScreen ? 400 : 550,
        height: 500,
        decoration:
            BoxDecoration(border: Border.all(color: Colors.blue.shade50)),
        child: Center(
          child: Scaffold(
            backgroundColor: const Color.fromRGBO(30, 130, 174, 1),
            appBar: AppBar(
              backgroundColor: Colors.blue.shade50,
              title: Row(
                children: [
                  Container(
                    margin: const EdgeInsets.all(2),
                    height: 40,
                    width: 40,
                    decoration: const BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                    ),
                    child: const Center(
                      child: Text(
                        'Æ',
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.w400),
                      ),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.all(2),
                    height: 40,
                    width: 40,
                    decoration: const BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                    ),
                    child: const Center(
                      child: Text(
                        'A',
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.w400),
                      ),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.all(2),
                    height: 40,
                    width: 40,
                    decoration: const BoxDecoration(
                      color: Colors.yellow,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                    ),
                    child: const Center(
                      child: Text(
                        'அ',
                        style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w400,
                            fontFamily: "MeeraInimai-Regular"),
                      ),
                    ),
                  ),
                ],
              ),
              actions: [
                IconButton(
                  onPressed: () {
                    _searchword.clear();
                    _searchHistory.clear();
                    setState(() {});
                  },
                  icon: const FaIcon(
                    FontAwesomeIcons.trashCan,
                    size: 15,
                  ),
                ),
                IconButton(
                  onPressed: () {
                    String copyText = "";
                    for (var index = 0; index < _searchword.length; index++) {
                      copyText += "\n${copyText + _searchword[index]}\n\n";
                      List isTamil = [];
                      for (var i = 0; i < _searchHistory[index].length; i++) {
                        isTamil.add(_searchHistory[index][i]["ta"] != null
                            ? true
                            : false);
                        String meaning1 = _searchHistory[index][i]["ta"] ??
                            _searchHistory[index][i]["no"] ??
                            "";

                        String? meaning2 =
                            _searchHistory[index][i]["ta"] != null
                                ? _searchHistory[index][i]["no"] ??
                                    _searchHistory[index][i]["en"] ??
                                    ""
                                : _searchHistory[index][i]["en"] ?? "";
                        copyText += "$meaning1${meaning2!}\n";
                      }
                    }
                    Clipboard.setData(ClipboardData(text: copyText)).then((_) {
                      ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Text Copied')));
                    });
                  },
                  icon: const Icon(Icons.copy_outlined, size: 15),
                ),
              ],
            ),
            body: Column(
              children: [
                SizedBox(
                  height: 392,
                  child: ListView.builder(
                    controller: _controller,
                    itemCount: _searchword.length,
                    itemBuilder: (context, index) {
                      final word = _searchword[index];
                      List<Widget> meaningList = [];
                      List<bool> isTamil = [];
                      for (var i = 0; i < _searchHistory[index].length; i++) {
                        isTamil.add(_searchHistory[index][i]["ta"] != null
                            ? true
                            : false);
                        String meaning1 = _searchHistory[index][i]["ta"] ??
                            _searchHistory[index][i]["no"] ??
                            "";

                        String? meaning2 =
                            _searchHistory[index][i]["ta"] != null
                                ? _searchHistory[index][i]["no"] ??
                                    _searchHistory[index][i]["en"] ??
                                    ""
                                : _searchHistory[index][i]["en"] ?? "";
                        meaningList.add(Container(
                          padding: const EdgeInsets.only(top: 5, bottom: 5),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                width: meaning1.length > 15 && isMobileScreen
                                    ? 100
                                    : null,
                                child: IntrinsicWidth(
                                  child: Text("$meaning1 ",
                                      textAlign: TextAlign.left,
                                      style: const TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                      )),
                                ),
                              ),
                              SizedBox(
                                width: meaning1.length > 15 && isMobileScreen
                                    ? 100
                                    : null,
                                child: IntrinsicWidth(
                                  child: Text(meaning2!,
                                      textAlign: TextAlign.right,
                                      style: const TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.bold)),
                                ),
                              ),
                            ],
                          ),
                        ));
                      }

                      return Container(
                        padding: const EdgeInsets.all(5),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Align(
                                  alignment: Alignment.centerLeft,
                                  child: Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 20, vertical: 5),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(5),
                                        color: Colors.white,
                                      ),
                                      child: Column(
                                        children: [
                                          Text(word,
                                              style: const TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.bold)),
                                           ContextMenuRegion(
                                             contextMenuBuilder:
                                                 (context, offset) {
                                                 
                                               return AdaptiveTextSelectionToolbar
                                                   .buttonItems(
                                                 anchors:
                                                     TextSelectionToolbarAnchors(
                                                   primaryAnchor: offset,
                                                 ),
                                                 buttonItems: <ContextMenuButtonItem>[
                                                   ContextMenuButtonItem(
                                                     onPressed: () {
                                                       // ContextMenuController
                                                       //     .removeAny();
                                                       // Navigator.of(context)
                                                       //     .push(_showDialog(
                                                       //         context));
                                                     },
                                                     label: 'Save',
                                                   ),
                                                 ],
                                               );
                                             },
                                             child: Text("--you",
                                                 style: TextStyle(
                                                     fontSize: 13,
                                                     fontWeight:
                                                         FontWeight.normal)),
                                           ),
                                        ],
                                      )),
                                )
                              ],
                            ),
                            IntrinsicWidth(
                              child: Container(
                                margin: const EdgeInsets.symmetric(vertical: 5),
                                // width: 300,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(5),
                                  color: Colors.white,
                                ),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 20, vertical: 5),
                                child: Column(children: [
                                  for (var i = 0; i < meaningList.length; i++)
                                    meaningList[i],
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      SizedBox(
                                          height: 20,
                                          child: isTamil.contains(true)
                                              ? const Text("--தமிழ்,English",
                                                  style: TextStyle(
                                                      fontSize: 13,
                                                      fontWeight:
                                                          FontWeight.normal))
                                              : const Text("--Norsk,English",
                                                  style: TextStyle(
                                                      fontSize: 13,
                                                      fontWeight:
                                                          FontWeight.normal))),
                                    ],
                                  ),
                                ]),
                              ),
                            )
                          ],
                        ),
                      );
                    },
                  ),
                ),
                Row(
                  children: [
                    Expanded(
                      child: Container(
                          padding: const EdgeInsets.only(left: 10),
                          height: 50,
                          color: Colors.white,
                          child: TextField(
                            controller: _searchController,
                            onSubmitted: (String val) {
                              _searchWord(val);
                            },
                            style: const TextStyle(
                                fontSize: 18, fontWeight: FontWeight.bold),
                            decoration: const InputDecoration(
                              border: InputBorder.none,
                              hintText: 'TYPE HERE',
                              hintStyle: TextStyle(
                                  fontSize: 20, fontWeight: FontWeight.normal),
                            ),
                          )),
                    ),
                    Container(
                        color: const Color.fromRGBO(13, 202, 240, 1),
                        width: 48,
                        height: 50,
                        child: IconButton(
                            onPressed: () {
                              _searchWord(_searchController.text);
                            },
                            icon: const FaIcon(
                              FontAwesomeIcons.paperPlane,
                              color: Colors.white,
                              size: 20,
                            )))
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}



typedef ContextMenuBuilder = Widget Function(
    BuildContext context, Offset offset);

/// Shows and hides the context menu based on user gestures.
///
/// By default, shows the menu on right clicks and long presses.
class ContextMenuRegion extends StatefulWidget {
  /// Creates an instance of [ContextMenuRegion].
  const ContextMenuRegion({
    super.key,
    required this.child,
    required this.contextMenuBuilder,
  });

  /// Builds the context menu.
  final ContextMenuBuilder contextMenuBuilder;

  /// The child widget that will be listened to for gestures.
  final Widget child;

  @override
  State<ContextMenuRegion> createState() => _ContextMenuRegionState();
}

class _ContextMenuRegionState extends State<ContextMenuRegion> {
  Offset? _longPressOffset;

  final ContextMenuController _contextMenuController = ContextMenuController();

  static bool get _longPressEnabled {
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
      case TargetPlatform.iOS:
        return true;
      case TargetPlatform.macOS:
      case TargetPlatform.fuchsia:
      case TargetPlatform.linux:
      case TargetPlatform.windows:
        return false;
    }
  }

  void _onSecondaryTapUp(TapUpDetails details) {
    _show(details.globalPosition);
  }

  void _onTap() {
    if (!_contextMenuController.isShown) {
      return;
    }
    _hide();
  }

  void _onLongPressStart(LongPressStartDetails details) {
    _longPressOffset = details.globalPosition;
  }

  void _onLongPress() {
    assert(_longPressOffset != null);
    _show(_longPressOffset!);
    _longPressOffset = null;
  }

  void _show(Offset position) {
    _contextMenuController.show(
      context: context,
      contextMenuBuilder: (context) {
        return widget.contextMenuBuilder(context, position);
      },
    );
  }

  void _hide() {
    _contextMenuController.remove();
  }

  @override
  void dispose() {
    _hide();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onSecondaryTapUp: _onSecondaryTapUp,
      onTap: _onTap,
      onLongPress: _longPressEnabled ? _onLongPress : null,
      onLongPressStart: _longPressEnabled ? _onLongPressStart : null,
      child: widget.child,
    );
  }
}