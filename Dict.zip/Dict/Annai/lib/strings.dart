String developerDetail="Dictionary Developed by Ingersol Selvaraj";

String copyFooter="© 2023 Annai Poopathi Tamilsk Kultursenter Nedre rommen 3A ,0988 Oslo, Norway";

String developerWebsite="Developed by kavadi.in";

String appNameTamil="அன்னை பூபதி தமிழ்க்கலைக்கூடம்";